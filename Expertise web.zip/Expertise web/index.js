const explanatoryTexts = document.querySelectorAll('.explanatoryText');

explanatoryTexts.forEach((element, index) => {
    element.style.marginLeft = `${index * 60}px`; // Aumenta 20px a cada elemento
});